<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

	//import joomla controller library
	jimport('joomla.application.component.controller');

	/**
	* Controleur du composant Gestion de Projet
	*/
	class GestionProjetController extends JControllerLegacy
	{
		/**
		  * Fonction bidon de test
		  * Affiche toto et demande l'affichage de la vue en utilisant le template default_toto.php
		  */
		public function toto ()
		{
			echo 'toto';
			$this->_display('toto');
		}

		/**
		  * Récupère et renvoie la vue par défaut du controller
		  * @return $object - la vue
		  */
		public function _getView()
		{
			//on récupère la vue code copier coller de la méthode display de la classe JController
			//définie à la ligne 580 de libraries/joomla/application/component/controller.php
			$document = JFactory::getDocument();
			$viewType = $document->getType();
			$viewName = JRequest::getCmd('view', $this->default_view);
			$viewLayout = JRequest::getCmd('layout', 'default');

			$view = parent::getView($viewName, $viewType, '', array('base_path' => $this->basePath, 'layout' => $viewLayout));

			// Get/Create the model
			if ($model = $this->getModel($viewName))
			{
				// Push the model into the view (as default)
				$view->setModel($model, true);
			}

			return $view;
		}

		/**
		  * Récupère la vue et appelle la méthode display de cette dernière
		  * @param $tpl string - le template que la vue doit utiliser
		  * @return void
		  */
		public function _display($tpl = null, $view = null)
		{
			if($view == null)
			{
				$view = $this->_getView();
			}

			//on appelle la méthode display de la vue qui se charge de récupérer les données à afficher
			$view->display($tpl);
		}


		/**
		  * Tache pour la page d'accueil de l'espace gestion de projet
		  * Vérifie les droits de l'utilisateurs avant d'appeler la méthode de la vue correspondante
		  * @return void
		  * @TODO vérfier que l'utilisateur est un étudiant
		*/
		public function afficher_projets()
		{
			$user = JFactory::getUser();

			//on vérifie que l'utilisateur est connecté
			if(!$user->guest)
			{
				$view = $this->_getView();
				$view->afficher_projets($user);
			}
			else
			{
				$this->_display('acces_interdit');
			}
		}

		/**
		  * Tache pour l'affichage d'un projet
		  * Vérifie les droits de l'utilisateur avant d'appeler la méthode de la vue correspondante
		  * @input : id_projet : l'id du projet à afficher
		  * @return void
		  * @TODO vérifier que l'utilisateur est un étudiant
		*/
		public function afficher_projet()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			$id_projet = $input->getInt('id_projet');

			//on vérifie que l'id est renseigné
			if($id_projet != null)
			{
				//on vérifie que l'utilisateur est connecté
				if(!$user->guest)
				{
					$view = $this->_getView();
					$view->afficher_projet($id_projet);
				}
				else
				{
					$this->_display('acces_interdit');
				}
			}
			else
			{
				$this->_display('projet_introuvable');
			}
		}

		/**
		  * Tache pour l'ajout d'un membre à un projet
		  * @input : id_projet - int : id du projet auquel ajouter le membre
		  * @input : id_membre - int : id du membre à ajouter
		  * @return void
		  */
		public function ajouter_membre()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			//on récupère le model et la vue
			$model = $this->getModel();
			$view = $this->_getView();
			$view->setModel($model);

			//on récupère les infos dans la requête
			$id_projet = $input->getInt('id_projet', false);
			$id_membre = $input->getInt('id_membre', false);
			$submit = $input->get('submit', false, null);

			//on vérifie que l'utilisateur est connecté
			if(!$user->guest)
			{
				//on vérifie qu'on a bien un id pour le projet
				if($id_projet == false)
				{
					$view->setErreur("Aucun projet spécifié");
					$view->display('erreur');
				}
				else
				{
					//on vérifie que l'utilisateur connecté est propriétaire du projet
					if($model->estProprietaire($user->id, $id_projet))
					{
						/* Si le formulaire a été envoyé on le traite */
						if($submit == 'Valider')
						{
							if($id_membre != false)
							{
								//on vérifie que le membre existe et qu'il n'est pas déjà membre du projet
								if(!$model->estMembre($id_membre, $id_projet) && JFactory::getUser($id_membre)->id != 0)
								{
									if($model->ajouterMembre($id_membre, $id_projet, 0))
									{
										$view->setMessage("Le membre a bien été ajouté.");
										$this->_display('message', $view);
									}
									else
									{
										$view->setErreur("Une erreur interne est survenue : ".$model->getErreur());
										$this->_display('erreur');
									}
									
								}
								else
								{
									$view->setErreur("Le membre demandé n'existe pas ou est déjà membre du projet.");
									$this->_display('erreur');
								}
							}
							else
							{
								$view->setErreur("Aucun id de membre spécifié.");
								$this->_display('erreur');
							}
						}
						/* Sinon on affiche le formulaire */
						else
						{
							$view->setMessage($id_projet);
							$this->_display('ajouter_membre');
						}
					}
					else
					{
						$this->_display('acces_interdit');
					}
				}
			}
			else
			{
				$this->_display('acces_interdit');
			}
		}

		/**
		  * Tache pour la suppression d'un membre
		  * @input : id_membre - int : id du membre à supprimer
		  * @input : id_projet - int : id du projetoù on supprime le membre
		  * @return void
		  */
		public function supprimer_membre()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			//on récupère le model et la vue
			$model = $this->getModel();
			$view = $this->_getView();
			$view->setModel($model);

			//on récupère les infos dans la requête
			$id_projet = $input->getInt('id_projet', false);
			$id_membre = $input->getInt('id_membre', false);

			//on vérifie si l'utilisateur est connecté
			if(!$user->guest)
			{
				//on vérifie qu'on a toutes les infos
				if($id_projet && $id_membre)
				{
					//on vérifie que l'utilisateur est bien propriétaire du projet
					if($model->estProprietaire($user->id, $id_projet))
					{
						//on vérifie que le propriétaire n'est pas en train d'essayer de se supprimer
						if($user->id != $id_membre)
						{
							//on supprime le membre
							if($model->supprimerMembre($id_membre, $id_projet))
							{
								$view->setMessage("Le membre a bien été supprimé.");
								$this->_display('message');
							}
							else
							{
								$view->setErreur("Une erreur interne est survenue : ".$model->getErreur());
								$this->_display('erreur');
							}
						}
						else
						{
							$view->setErreur("Vous ne pouvez pas vous supprimer vous même");
							$this->_display('erreur');
						}
					}
					else
					{
						$view->setErreur("Vous n'êtes pas propriétaire du projet.");
						$this->_display('acces_interdit');
					}
				}
				else
				{
					$view->setErreur("Aucun id de projet ou de membre renseigné");
					$this->_display('erreur');
				}
			}
			else
			{
				$this->_display('acces_interdit');
			}
		}

		/**
		  * Tache pour le transfert de droits
		  * @input : id_membre - int : id du membre à promouvoir
		  * @input : id_projet - int : id du projet concerné
		  * @return void
		  */
		public function transferer_droits ()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			//on récupère le model et la vue
			$model = $this->getModel();
			$view = $this->_getView();
			$view->setModel($model);

			//on récupère les infos dans la requête
			$id_projet = $input->getInt('id_projet', false);
			$id_membre = $input->getInt('id_membre', false);

			//on vérifie si l'utilisateur est connecté
			if(!$user->guest)
			{
				//on vérifie qu'on a toutes les infos
				if($id_projet && $id_membre)
				{
					//on vérifie que l'utilisateur est bien propriétaire du projet
					if($model->estProprietaire($user->id, $id_projet))
					{
						//on effectue le tranfert des droits
						if($model->transfererDroits($id_membre, $user->id, $id_projet))
						{
							$view->setMessage("Le tranfert des droits a été effectué.");
							$this->_display('message');
						}
						else
						{
							$view->setErreur("Une erreur interne est survenue : ".$model->getErreur());
							$this->_display('erreur');
						}
					}
					else
					{
						$view->setErreur("Vous n'êtes pas propriétaire du projet.");
						$this->_display('acces_interdit');
					}
				}
				else
				{
					$view->setErreur("Aucun id de projet ou de membre renseigné");
					$this->_display('erreur');
				}
			}
			else
			{
				$this->_display('acces_interdit');
			}
		}

		public function afficher_membres()
		{
			$this->_display('afficher_membres');
		}

		/**
		  * Tache pour la création d'un projet
		  * Si le formulaire de création a été envoyé, on créer un nouveau projet
		  * @input : nom
		  * @input : nom_court
		  * @input : description
		  * @input : submit
		  * @return void
		  */
		public function creer_projet()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			// On récupère le model et la vue
			$model = $this->getModel();
			$view = $this->_getView();
			$view->setModel($model);

			//on vérifie que l'utilisateur est connecté
			if(!$user->guest)
			{
				$submit = $input->get('submit');
				/* Si le formulaire a été envoyé on le traite */
				if($submit == 'Valider')
				{
					/* on récupère les infos*/
					$nom = $input->get('nom', null, null);
					$nom_court = $input->get('nom_court', null, null);
					$description = $input->get('description', null, null);

					/* On vérifie qu'on a toutes les infos */
					if($nom && $nom_court && $description)
					{
						/* On crée le projet */
						if($model->creerProjet($nom, $nom_court, $description, $user->id))
						{
							$view->setMessage("Le projet a bien été créé.");
							$this->_display('message', $view);
						}
						else
						{
							$view->setErreur("Une erreur interne est survenue : ".$model->getErreur());
							$this->_display('erreur');
						}
						
					}
				}
				/* Sinon on affiche le formulaire */
				else
					$this->_display('creer_projet');
			}
			else
			{
				$this->_display('acces_interdit');
			}
			
		}

		public function supprimer_projet()
		{
			$user = JFactory::getUser();
			$input = JFactory::getApplication()->input;

			//on vérifie que l'utilisateur est connecté
			if(!$user->guest)
			{
				echo 'traitement';

				/* on récupère l'info nécessaire*/
				
				$id_projet = $input->get('id_projet', null);
				
				/* On vérifie qu'on a toutes les infos */
				if($id_projet)
				{
					/* On récupère le model */
					$model = $this->getModel();
					
					if($model->estProprietaire($user->id, $id_projet))
					{
						/* On supprime le projet */
						if($model->supprimerProjet($id_projet, $user->id))
						{
							$this->_display('Le projet a été supprimé.');
						}
					}
					else
					{
						echo"Vous n'etes pas proprietaire du projet.";
					}
				}
				else
				{
					echo"Le projet n'existe pas.";
				}
			}
			else
			{
				$this->_display('acces_interdit');
			}
		}

		public function afficher_note()
		{
			$this->_display('afficher_note');
		}

		public function creer_note()
		{
			$this->_display('creer_note');
		}

		public function modifier_note()
		{
			$this->_display('modifier_note');
		}

		public function afficher_services()
		{
			$this->_display('afficher_services');
		}

		public function souscrire_service()
		{
			$this->_display('souscrire_service');
		}
	}
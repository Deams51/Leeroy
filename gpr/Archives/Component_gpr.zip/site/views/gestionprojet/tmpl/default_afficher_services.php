<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Projets - Affichage souscriptions -->
		<h1> Test Affichage souscriptions<br /></h1>
		<form Name ="form-visualisation" Method ="POST" ACTION = "afficher_souscriptions.php">
			ID projet <INPUT TYPE = "TEXT" Name = "id-projet" />
			ID membre <INPUT TYPE = "TEXT" Name = "id-membre" />
			<INPUT TYPE = "Submit" Name = "Submit-droits" VALUE = "Executer" />
		</form>
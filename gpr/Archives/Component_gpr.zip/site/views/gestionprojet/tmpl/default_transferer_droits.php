<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>
<!-- Projets - Transfert droits -->
		<h1> Test transfert droits<br /></h1>
		<form Name ="form-droits" Method ="POST" ACTION = "Transfert_droit.php">
			ID projet <INPUT TYPE = "TEXT" Name = "id-projet" />
			ID membre de <INPUT TYPE = "TEXT" Name = "id-membre-d" />
			ID membre vers<INPUT TYPE = "TEXT" Name = "id-membre-v" />
			<INPUT TYPE = "Submit" Name = "Submit-droits" VALUE = "Executer" />
		</form>
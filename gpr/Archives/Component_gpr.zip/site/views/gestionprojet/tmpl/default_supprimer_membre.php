<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>
<h1>Supprimer un membre</h1>
<p>Rien ici</p>
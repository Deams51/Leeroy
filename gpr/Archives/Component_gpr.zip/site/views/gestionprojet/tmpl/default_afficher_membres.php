<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- projet - Visualisation liste membres -->
		<h1>Test gestion team</h1>
		<form method="get" action="">
			mon ID membre<input type="text" name="id_lecteur" />
			ID projet<input type="texte" name="id_projet" />
			<input type="submit" value="afficher" />
		</form>
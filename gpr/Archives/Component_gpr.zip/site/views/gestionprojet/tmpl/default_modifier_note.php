<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Postit - Modifer note -->
<h1>Test modifer note<br /></h1>
<form method="get" action="modifier_postit.php">
	ID postit <input type="text" name="id_postit" />
	contenu <textarea name="texte"></textarea>
	<input type="submit" value="modifer" />
</form>
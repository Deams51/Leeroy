<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Postit - Créer note -->
<h1>Test créer note</h1>
<form method="get" action="creer_postit.php">
	ID membre <input type="text" name="id_membre" />
	ID projet <input type="text" name="id_projet" />
	<input type="submit" value="créer" />
</form>
<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');
?>

<!-- @TODO Lien ou formulaire pour ajouter un projet -->

<h1>Mes projets</h1>
<?php
	if(count($this->msg) > 0)
	{
		echo '<table>';
		echo 	'<thead>
					<th>Nom Projet</th>
					<th>Nom court</th>
					<th>Description</th>
					<th></th>
					<th></th>
				</thead>';
		echo '<tbody>';
		foreach ($this->msg as $key => $projet) {
			echo '<tr>';
				echo '<td>';
					echo '<a href="'.JRoute::_('index.php?option=com_gestionprojet&task=afficher_projet&id_projet='.$projet['id']).'" title="Voir le projet">'.$projet['nom'].'</a>';
				echo '</td>';
				echo '<td>';
					echo $projet['nom_court'];
				echo '</td>';
				echo '<td>';
					echo $projet['description'];
				echo '</td>';
				echo '<td>';
					if($projet['statut'] == 1)
						echo 'Etoile';
				echo '</td>';
				echo '<td>';
					if($projet['token'] == 1)
						echo 'Notif';
				echo '</td>';
			echo '</tr>';
		}
		echo '</tbody>';
		echo '</table>';
	}
	else
	{
		echo '<p>Aucun projet pour l\'instant</p>';
	}
?>
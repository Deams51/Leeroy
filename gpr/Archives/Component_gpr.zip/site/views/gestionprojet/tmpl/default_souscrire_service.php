<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Projets - Souscrir service -->
		<h1> Test Souscription services<br /></h1>	
		<form Name ="form-ajout" Method ="POST" ACTION = "souscription.php">
		Mon ID membre <INPUT TYPE = "TEXT" Name = "id-membre" />
		ID projet <INPUT TYPE = "TEXT" Name = "id-projet" /><br />
		
			<input type="checkbox" name="SVN" value="SVN" /> SVN<br />
			<input type="checkbox" name="Trackr" value="Trackr" /> Trackr<br />
			<input type="checkbox" name="Tuleap" value="Tuleap" /> Tuleap<br />
			<INPUT TYPE = "Submit" Name = "Submit-droits" VALUE = "Executer" />
		</form>
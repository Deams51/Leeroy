<?php
	//Empeche l'acces direct au fichier
	defined('_JEXEC') or die ('Restricted access');
?>

<?php
	if(count($this->msg['infos_projet']) > 0)
	{
		//on récupère l'utilisateur connecté
		$user = JFactory::getUser();
		//statut de l'utilisateur (true si propriétaire, false si membre
		$proprietaire = $this->getModel()->estProprietaire($user->id, $this->msg['infos_projet']['id']);

		echo "<table>";
		echo "<thead><th>Projet : ".$this->msg['infos_projet']['nom']."</th></thead>";
		echo "</table>";

		echo "<table>";
		//les infos des membres du projet son affichées ici
		echo '<thead><th colspan="'.count($this->msg['infos_membres']).'">Mon équipe</th></thead>';
		echo "<tbody>";

		echo "<tr>";
		foreach ($this->msg['infos_membres'] as $key => $membre)
		{
			echo "<td><a href=\"#\">".$membre['nom']."</a></td>";
		}
		echo "</tr>";

		//si l'utilisateur connecté est propriétaire on affiche les liens pour supprimer un membre et tranférer les droits
		if($proprietaire)
		{
			echo "<tr>";
			foreach ($this->msg['infos_membres'] as $key => $membre)
			{
				echo '<td>';
				//si l'utilisateur connecté est différent de celui traité
				if($membre['id'] != $user->id)
				{
					echo '<a 
						href="'.JURI::root().'index.php?option=com_gestionprojet&task=supprimer_membre&id_membre='.$membre['id'].'&id_projet='.$this->msg['infos_projet']['id'].'">
						Supprimer membre</a>';
				}
				echo '</td>';
			}
			echo "</tr>";

			echo "<tr>";
			foreach ($this->msg['infos_membres'] as $key => $membre)
			{
				echo '<td>';
				//si l'utilisateur connecté est différent de celui traité
				if($membre['id'] != $user->id)
				{
					echo '<a 
						href="'.JURI::root().'index.php?option=com_gestionprojet&task=transferer_droits&id_membre='.$membre['id'].'&id_projet='.$this->msg['infos_projet']['id'].'">
						Transférer les droits</a>';
				}
				echo '</td>';
			}
			echo "</tr>";
		}

		echo "</tbody>";
		echo "</table>";

		echo "<table>";
		echo "<thead><th>Infos Projet</th></thead>";
		//les services souscrits sont affichés ici
		echo "<tbody><tr>";
			echo "<td><span style=\"font-weight:bold\">Services souscrits : </span>";
			echo "".$this->msg['infos_projet']['services']."</td>";
		echo "</tr>";
		// les news du projet sont affichées ici
		echo "<tr>";
			echo "<td><span style=\"font-weight:bold\">News : </span>";
			echo "Afficher les news ici ...</td>";
		echo "</tr>";
		echo "</tbody></table>";

		if($proprietaire)
		{
			// mettre ici tous les liens réservés au chef de projet
			echo '<a href="'.JURI::root().'index.php?option=com_gestionprojet&task=ajouter_membre&id_projet='.$this->msg['infos_projet']['id'].'" 
					title="Ajouter un membre au projet">Ajouter un membre</a>';
			echo '<a href="'.JURI::root().'index.php?option=com_gestionprojet&task=supprimer_projet&id_projet='.$this->msg['infos_projet']['id'].'">
						Supprimer le projet</a>';
		}
	}
	else
	{
		echo "<tr>Le projet demandé n'existe pas.</tr>";
	}
?>
<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Projets - Supprimer projet -->
		<h1> Test supprimer projet<br /></h1>
		<form Name ="form-visualisation" Method ="POST" ACTION = "Supprimer_Projet.php">
			ID projet <INPUT TYPE = "TEXT" Name = "id-projet" />
			ID membre <INPUT TYPE = "TEXT" Name = "mid-membre" />
			<INPUT TYPE = "Submit" Name = "Submit-droits" VALUE = "Executer" />
		</form>
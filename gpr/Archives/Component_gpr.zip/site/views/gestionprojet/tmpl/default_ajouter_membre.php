<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Projets - Ajout membres -->
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
		<h1> Test ajout membres</h1>	
		<form method="post" action=<?php echo "\"".JRoute::_('')."\""; ?>>
			ID membre a ajouter<input type = "text" name = "id_membre" />
			<input type = "submit" name="submit" VALUE="Valider" />
			<script language="JavaScript" type="text/JavaScript">
				//$("#mid").onkeyup(
				function functionCompletion()
				{
					new $.Autocompleter ('mid',
                        'mid_update',
                        'listSuggestion.php',
                        {
                                method: 'post',
                                paramname: 'mid',
                                afterUpdateElement: ac_return
                        });
					function ac_return(field, item){
							
							//on récupère l'id
							id = nomimage[0].replace('-mini', '');
							// et on l'affecte au champ caché
							$(field.name+'_id').value = id;
					}
					//var text = $("#mid").val();
					//var list = [];
					//$.ajax("listSuggestion.php?param="+text);
					//alert(text);
				}//);
			</script>
		</form>
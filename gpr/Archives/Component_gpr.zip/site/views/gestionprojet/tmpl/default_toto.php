<?php
	//Empeche l'acces direct au fichier
	defined('_JEXEC') or die ('Restricted access');
?>
<!-- Ce template sera inclu par la classe JView. $this se réfère donc à la classe de la vue (GestionProjetViewGestionProjet) -->
<h3><?php echo $this->msg; ?></h3>
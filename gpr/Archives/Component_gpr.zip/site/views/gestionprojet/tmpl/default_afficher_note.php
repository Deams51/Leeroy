<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<!-- Postit - afficher postit -->
<h1>Test afficher note<br /></h1>
<form method="get" action="afficher_postit.php">
	ID postit <input type="text" name="id_postit" />
	ID lecteur<input type="text" name="id_lecteur" />
	<input type="submit" value="afficher" />
</form>
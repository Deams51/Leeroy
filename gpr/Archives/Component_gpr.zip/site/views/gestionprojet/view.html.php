<?php
	/**
	  * Vue pour le côté utilisateur du composant gestion de projet
	  * La vue se charge de récupérer les informations au niveau du modele et les affiche en utilisant un template
	*/

	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

	//import joomla view library
	jimport('joomla.application.component.view');

	/**
	* HTML View class pour le composant Gestion de Projet
	*/
	class GestionProjetViewGestionProjet extends JViewLegacy
	{
		//contient le message d'erreur
		protected $erreur;

		//contient le essage ou les données à afficher
		protected $msg;

		/**
		  * set message d'erreur
		  */
		public function setErreur($err)
		{
			$this->erreur = $err;
		}

		/**
		  * set message
		  */
		public function setMessage($message)
		{
			$this->msg = $message;
		}

		//Overwriting JView display method
		public function display($tpl = '')
		{
			//Check for errrors
			if(count($errors = $this->get('Errors')))
			{
				JError::raiseError(500, implode('<br />', $errors));
				return false;
			}

			//display the view using $tpl as template
			parent::display($tpl);
		}

		/**
		  * Récupère la liste des projets et tps de l'utilisateur et les affiche
		  * @param $user - int : L'utilisateur dont on veut récupérer les projets/tps
		  */
		public function afficher_projets($user)
		{
			$model = $this->getModel();
			$this->msg = $model->getProjTp($user->id);

			if($this->msg !== false)
			{
				$this->display('afficher_projets');
			}
			else
			{
				$this->erreur = $model->getErreur();
				$this->display('erreur');
			}
		}

		/**
		  * Récupère le projet en question et l'affiche
		  * @param : $id_projet - int : le projet à afficher
		  * 
		  */
		public function afficher_projet($id_projet)
		{
			$model = $this->getModel();
			$this->msg = array();

			//on récupère les infos du projet
			$this->msg['infos_projet'] = $model->getProjet($id_projet);

			//on vérifie qu'on a un résultat
			if($this->msg['infos_projet'] !== false)
			{
				//on récupère les infos des membres du projet
				$this->msg['infos_membres'] = $model->getInfosMembres($id_projet);

				//on vérifie qu'on a un résultat
				if($this->msg['infos_membres'] !== false)
				{
					$this->display('afficher_projet');
				}
				else
				{
					$this->erreur = $model->getErreur();
					$this->display('erreur');
				}
			}
			else
			{
				$this->erreur = $model->getErreur();
				$this->display('erreur');
			}
		}
	}
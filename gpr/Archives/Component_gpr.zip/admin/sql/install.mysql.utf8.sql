-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Version du serveur: 5.5.27
-- Version de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `test`
--

-- --------------------------------------------------------
--
-- Structure de la table `gpr_membres`
--

CREATE TABLE IF NOT EXISTS `gpr_membres` (
  `id_joomla` int(11) NOT NULL,
  `id_projet` int(11) NOT NULL,
  `id_postit` int(11) NOT NULL,
  `statut` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
--
-- Structure de la table `gpr_postit`
--

CREATE TABLE IF NOT EXISTS `gpr_postit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texte` text CHARACTER SET utf8 NOT NULL,
  `token` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Token est le vu/modifié ou non.' AUTO_INCREMENT=4 ;

-- --------------------------------------------------------
--
-- Structure de la table `gpr_projet`
--

CREATE TABLE IF NOT EXISTS `gpr_projet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `nom_court` varchar(25) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `date_creation` date NOT NULL,
  `date_fin` date NOT NULL,
  `is_tp` tinyint(1) NOT NULL,
  `services` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


-- --------------------------------------------------------
--
-- Données de Test : Ecrase tout.
--
--
-- Contenu de la table `gpr_membres`
--
INSERT IGNORE INTO `gpr_membres` (`id_joomla`, `id_projet`, `id_postit`, `statut`) VALUES
(74, 1, 2, 0),
(814, 1, 1, 1),
(14, 0, 3, 0),
(66, 1, 76, 1),
(12, 1, 1, 1);

--
-- Contenu de la table `gpr_projet`
--
INSERT IGNORE INTO `gpr_projet` (`id`, `nom`, `nom_court`, `description`, `date_creation`, `date_fin`, `is_tp`, `services`) VALUES
(1, 'gpr_projet 1', '', '', '2013-03-04', '2015-01-09', 0, 'SVN:Trackr:Tuleap');

--
-- Contenu de la table `gpr_postit`
--
INSERT IGNORE INTO `gpr_postit` (`id`, `texte`, `token`) VALUES
(1, 'ratati', 0),
(2, '', 0),
(3, '', 0);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
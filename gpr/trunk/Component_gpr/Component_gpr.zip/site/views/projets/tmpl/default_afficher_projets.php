<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');
	JHTML::script(JURI::base().'components/com_gpr/assets/js/intro.js');
	$document->addStyleSheet('components/com_gpr/assets/css/introjs.css');
	$document->addStyleSheet('components/com_gpr/assets/css/introjs-ie.css');
?>

<!-- @TODO Lien ou formulaire pour ajouter un projet -->
<table class="table table-striped" id="vpsList" data-step="1" data-intro="Hello all! :)">
<h1>Mes projets</h1>
<?php
	echo "ici";
	if(count($this->msg) > 0)
	{
		echo '<table>';
		echo 	'<thead>
					<th>Nom Projet</th>
					<th>Description</th>
					<th>Chef</th>
					<th>Notification</th>
				</thead>';
		echo '<tbody>';
		foreach ($this->msg as $key => $projet) {
			echo '<tr>';
				echo '<td>';
					echo '<a href="'.JRoute::_('index.php?option=com_gpr&task=projets.afficher&view=projets&id_projet='.$projet['id']).'" title="Voir le projet">'.$projet['nom'].'</a>';
				echo '</td>';
				echo '<td>';
					echo $projet['description'];
				echo '</td>';
				echo '<td>';
					if($projet['statut'] == 1)
						echo '<img height="25" length="25" src="'.JURI::base().'administrator/components/com_gpr/assets/images/star.png" alt="*"/>';
				echo '</td>';
				echo '<td>';
					if($projet['token'] == 1)
						echo '<img height="25" length="25" src="'.JURI::base().'administrator/components/com_gpr/assets/images/notif_red.png" title="Votre postit a été modifé" alt="(!)" />';
					else
						echo '<img height="25" length="25" src="'.JURI::base().'administrator/components/com_gpr/assets/images/notif_black.png" title="Pas de nouveau postit"/>';
				echo '</td>';
			echo '</tr>';
		}
		echo '</tbody>';
		echo '</table>';
	}
	else
	{
		echo '<p>Aucun projet pour l\'instant</p>';
	}
?>
</table>
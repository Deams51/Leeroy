<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<h1>Creer projet</h1>
<form method="post" action="<?php echo JRoute::_(''); ?>">
	<label for="nom">Nom du projet : </label><input type="text" name="nom" /><br />
	<label for="description">Description : </label><br />
	<textarea rows="7" name="description"></textarea><br />
	<input type="submit" name="submit" value="Valider" /><br />
</form>
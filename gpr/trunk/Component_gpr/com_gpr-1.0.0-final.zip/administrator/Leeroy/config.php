<?php
$domain = 'stic-test.tk';
$username = 'remote';
$password = '3EEdWgm2SMsCV';
$client_id = 0;
$server_id = 1;
$ostemplate_id = 1;	
$template_id = 3;

/*
$soap_location = 'https://ks305853.kimsufi.com:8080/ispconfig3_3.0.5/interface/web/remote/index.php';
$soap_uri = 'https://ks305853.kimsufi.com:8080/ispconfig3_3.0.5/interface/web/remote/';
*/
$soap_location = 'https://localhost:8080/remote/index.php';
$soap_uri = 'https://localhost:8080/remote/';
?>
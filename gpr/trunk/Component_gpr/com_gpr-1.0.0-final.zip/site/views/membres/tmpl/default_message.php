<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>
<h2>Confirmation</h2>
<?php
	echo "<p>".$this->msg."</p>";
?>
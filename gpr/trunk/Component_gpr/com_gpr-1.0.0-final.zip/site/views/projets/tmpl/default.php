<?php
	/**
	  * Template par défaut pour l'affichage du composant gestion de projet
	  * N'est plus utilisé
	  * A priori, il est impossible qu'il soit appelé ...
	*/
	//Empeche l'acces direct au fichier
	defined('_JEXEC') or die ('Restricted access');
?>
<!-- Ce template sera inclu par la classe JView. $this se réfère donc à la classe de la vue (gprViewgpr) -->
<h1>Espace gestion de projet</h1>
<p>Vous n'avez rien à faire sur cette page</p>
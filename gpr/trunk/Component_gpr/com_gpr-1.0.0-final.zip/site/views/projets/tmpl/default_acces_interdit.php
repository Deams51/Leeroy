<?php
	//empeche l'accès direct au fichier
	defined('_JEXEC') or die ('Restricted access');

?>

<h1>Accès interdit</h1>
<?php
	if($this->erreur)
	{
		echo "<p>".$this->erreur."</p>";
	}
	else
	{
		echo "<p>Vous devez être enregistré sur le site pour accéder à cette page</p>";
	}
?>